const crypto = require("crypto");

/**
 * First of all, the RECIPIENT obtains MESSAGE and HASH
 * (can be MD5, SHA1, or SHA256) from the SENDER
 */
const message = "this is a fake secret";
const senderHash = "2cf33591c3b28b382668952e236cczzz"; // md5 hash
const senderHashSHA1 = "2321c6d320b84c6eeb1c8b88aa44e636284c9afb" // ini yg SHA-1
const senderHashSHA2 = "ad6aaf9436af95ee9163f1da58b8b7af1018e3faa853209e5151c048bb058479" // ini yang SHA-2

// the RECIPIENT need to create their own version of the hash
const recipientHash = crypto.createHash("md5").update(message).digest("hex");
const isValid = (senderHash == recipientHash);
console.log("MD5 verification result is:", isValid);

const recipientHashSha1 = crypto.createHash("sha1").update(message).digest("hex");
const isValidSha1 = (senderHashSHA1 == recipientHashSha1);
console.log("SHA-1 verification result is:", isValidSha1);

const recipientHashSha2 = crypto.createHash("sha256").update(message).digest("hex");
const isValidSha2 = (senderHashSHA2 == recipientHashSha2);
console.log("SHA-2 verification result is:", isValidSha2);